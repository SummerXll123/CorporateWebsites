$(function () {
//加载join.html滚动条
    (function($){
        $(window).load(function(){
            $(".honor_box").mCustomScrollbar();
        });
    })(jQuery);




    //banner
    /*var $in_banner = $('.n_banner'),
        li_size    = $('.n_banner li').length,
        num        = 0,
        bannerroll = setInterval(move,3000);

    //定时器运行的函数
    function move(){
        var w_width = $(window).width();
        num<li_size-1?num++:num=0;

        $('.n_banner .num a').eq(num).addClass('on')
            .siblings().removeClass('on');

        if(w_width>999){//根据条件不同，滚动的距离
            $in_banner.find('ul').stop()
                .animate({marginLeft:-num*1920},800)
        }else{
            $in_banner.find('ul').stop()
                .animate({marginLeft:-num*w_width},800)
        };
    };

    //点击指示点，banner运行相应的图片
    $('.n_banner .num a').click(function() {
        var index   = $(this).index(),
            w_width = $(window).width();

        $(this).addClass('on')
            .siblings().removeClass('on');

        num=index;
        if(w_width>999){
            $in_banner.find('ul').stop()
                .animate({marginLeft:-num*1920},800)
        }else{
            $in_banner.find('ul').stop()
                .animate({marginLeft:-num*w_width},800);
        }
    });



    //鼠标经过banner清除定时，离开继续
    $in_banner.hover(function() {
        clearInterval(bannerroll)
    },function(){
        bannerroll=setInterval(move,3000);
    });
    //根据窗口大小判断加载不同的尺寸的图片
    function change(){
        var w_width=$(window).width();

        $in_banner.width(w_width);
        $in_banner.find('li').width(w_width);

        $('img').each(function() {
            if(w_width>999){
                $(this).attr('src',$(this).attr('data-1920'));
                $in_banner.width(1920);
                $in_banner.find('li').width(1920);
            }
            else if(w_width<=999&&w_width>640){
                $(this).attr('src',$(this).attr('data-990'));
            }
            else if(w_width<=640){
                $(this).attr('src',$(this).attr('data-640'));
            }
        })
    };

    //页面加载
    $(window).load(function() {
        change();
    });

    //窗口变化
    $(window).resize(function() {
        var w_width=$(window).width();
        change();
        if(w_width>999){
            $in_banner.find('ul').stop()
                .animate({marginLeft:-num*1920},800);
        }else{
            $in_banner.find('ul').stop()
                .animate({marginLeft:-num*w_width},800);
        }
    });
*/
    //隐藏的搜索
    $(".s_search").click(function() {
        $('.header-box .m_nav').show(500);
        $('.i_close').show(500);
        $('.header-box .nav').hide();

    });

    $(".i_close").click(function() {
        $('.header-box .nav').show(500);
        $('.m_nav').hide();
    });

//招聘信息

    $('.table_on').click(function(){
        $(this).toggleClass("on");
        $(this).parents('tr').next().stop().animate({
            height: "toggle",
            opacity: "toggle",
        },0)
    });

/*弹出职位申请*/
    $('.offer').click(function(){
        $('.zoom').show();
    });

    $('.apply .tit .close').click(function(){
        $('.zoom').hide();
    });


    $("input:not(:submit)").each(function(index, element) {
        if($(this).val()!=""){
            $(this).next("span").hide();
        }else{
            $(this).next("span").show();
        }
    });






$('.nav ul li').hover(function(){
        $(this).children('.bot_line').stop().animate({
            height: "toggle",
            opacity: "toggle"
        },150)

        $(this).children('.slide').stop().animate({
            height: "toggle",
            opacity: "toggle"
        },150)

    });

    //移动端隐藏的下拉菜单
    $(".header .m_menu").click(function() {
        $(".header .m-navwrap").slideToggle();
    });

    $(".m-navwrap ul li").click(function() {
        $(this).children('.yd_slide').slideDown();
        $(this).siblings().children('.yd_slide').slideUp();
    });
    //case水与办公
    $(".case_box .case_block a").hover(function() {
        $(this).siblings('a').removeClass('active');
        $(this).addClass('active');
        $(this).parents('.case_block').next('.case_tab').children('.case').eq($(this).index()).siblings('.case').css('display','none');
        $(this).parents('.case_block').next('.case_tab').children('.case').eq($(this).index()).css('display','block');
    });
//服务介绍

    $('.introduce ul li').click(function(){
        $(this).toggleClass("on");
        $(this).children('.slide_quality').stop().animate({
            height: "toggle",
            opacity: "toggle",
        },150)
    });

    /*sherry*/
    $("input:not(:submit)").each(function(index, element) {
        if($(this).val()!=""){
            $(this).next("span").hide();
        }else{
            $(this).next("span").show();
        }
    });
    var emailReg = /^[-._A-Za-z0-9]+@([_A-Za-z0-9]+\.)+[A-Za-z0-9]{2,3}$/;
    var phoneReg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1}))+\d{8})$/;
    ////////////////////////////////////////blur事件
    $("input:not(:submit),textarea:not(:submit)").blur(function(e) {
        var tips;
        var val=$(this).val();
        //必填
        if($(this).is(".required")){
            if(val!=""){
                $(this).next("span").hide().removeClass("tips");
            }else{
                $(this).next("span").show().addClass("tips");//以防填写信息后又删除之后出现空白
                if($(this).next("span").is(".span_tips")){//区分span_tips和普通的tips为空的提示
                    tips=$(this).next("span").html();
                }else{
                    tips="不能为空";
                }
            }
        }
        if(val){//不为空的情况下判断
            //判断邮件
            if($(this).is(".email")){
                if(!emailReg.test(val)){
                    //$(this).next("span").show().addClass("tips");
                    tips="邮件格式不正确";
                    layer.alert(tips);
                    //$(this).val("");
                    istrue = false;
                }else{
                    $(this).next("span").hide().removeClass("tips");
                    tips="";
                }
            }
            //判断手机号码
            if($(this).is(".phone")){
                if(!phoneReg.test(val)){
                    //$(this).next("span").show().addClass("tips");
                    tips="手机号码不正确";
                    layer.alert(tips);
                    //$(this).val("");
                    istrue = false;
                }else{
                    $(this).next("span").hide().removeClass("tips");
                    tips="";
                }
            }
            //判断确认密码
            if($(this).is(".re_pwd")){
                var pwd=$(this).parents().prev().children(".password");
                if(val!=pwd.val()){
                    //$(this).next("span").show().addClass("tips");
                    tips="密码不一致";
                    layer.alert(tips);
                    //$(this).val("");
                    istrue = false;

                }else{
                    $(this).next("span").hide().removeClass("tips");
                    tips="";
                }
            }
            //判断邮箱或者手机号码
            //判断手机号码
            if($(this).is(".email_phone")){
                if(!phoneReg.test(val)&&!emailReg.test(val)){
                    //$(this).next("span").show().addClass("tips");
                    tips="请输入正确的邮箱或者手机号码";
                    layer.alert(tips);
                    //$(this).val("");
                    istrue = false;
                }else{
                    $(this).next("span").hide().removeClass("tips");
                    tips="";
                }
            }
        }
        //提示位置判断
        $(this).next("span").html(tips);
    });

    /////////////////////////提交验证
    $('input:submit').on('click',function(){
        var $form=$(this).parents("form");
        var istrue=true;
        var require=$form.find(".required");
        var email=$form.find(".email");
        var phone=$form.find(".phone");
        var repwd=$form.find(".re_pwd");

        /*if(check_orno()==true){
         alert('true');
         istrue=true;
         }else{
         alert('false');
         istrue=false;
         }*/
        //判断必填
        if(require&&istrue){
            require.each(function(index, element) {
                var $span=$(this).next("span");
                if($(this).val()==""){
                    if($span.is(".span_tips")){
                        var tips=$span.html();
                    }else{
                        var tips="不能为空";
                    }
                    istrue = false;

                    $(this).val("");
                    $(this).next("span").html(tips);
                    $(this).next("span").show().addClass("tips");
                }
            });
        }
        return istrue;
    })

    function validate(obj){
        var $form=obj.parents("form");
        var istrue=true;
        var require=$form.find(".required");
        var email=$form.find(".email");
        var phone=$form.find(".phone");
        var repwd=$form.find(".re_pwd");
        if(check_orno()==true){
            istrue=true
        }else{
            istrue=false;
        }
        //判断必填
        if(require){
            require.each(function(index, element) {
                var $span=$(this).next("span");
                if($(this).val()==""){
                    if($span.is(".span_tips")){
                        var tips=$span.html();
                    }else{
                        var tips="不能为空";
                    }
                    istrue = false;
                    $(this).val("");
                    $(this).next("span").html(tips);
                    $(this).next("span").show().addClass("tips");
                }
            });
        }
        return istrue;
    }

 /*   function download(file) {
        window.location.href =URL+"/download?file=" + file;
    }

    function setFirstQ(){
        $.post(APP+'/Question/changQuestion', {id:$("a[class='subAnswer']").attr('question_id'),exam_id:$("a[class='subAnswer']").attr('exam_id')},function (data) { //回调函数
            $("input[name='questionoption'][value='"+data.answer+"']").attr("checked",true);
        })
    }

*/







});
