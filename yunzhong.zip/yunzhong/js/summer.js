$(function () {
    //top箭头
    $(window).scroll(function() {
        if ($(this).scrollTop() > 500) {
            $('.arrow').fadeIn();
        } else {
            $('.arrow').fadeOut();
        }
    })
    //二级菜单
    $('.nav ul li').hover(function(){
        $(this).children('.drop').stop().animate({
            height: "toggle",
            opacity: "toggle"
        },500)
    });
//banner
    var num        = 0,
        bannerroll = setInterval(move,4000);//定时器

    function move(){
        var w_width = $(window).width();
        num<$('.n_baner li').length-1?num++:num=0;

        $('.n_baner .num a')
            .eq(num)
            .addClass('on')
            .siblings()
            .removeClass('on');

        //根据不同条件，滚动距离
        if(w_width>999){
            $('.n_baner').find('ul')
                .stop()
                .animate({marginLeft:-num*1920},800)
        }else{
            $('.n_baner').find('ul')
                .stop()
                .animate({marginLeft:-num*w_width},800)
        };
    };


    //点击指示点，banner运行相应图片
    $('.n_baner .num a').click(function() {
        var index   = $(this).index(),
            w_width = $(window).width();

        $(this).addClass('on')
            .siblings().removeClass('on');

        num=index;
        if(w_width>999){
            $('.n_baner').find('ul')
                .stop()
                .animate({marginLeft:-num*1920},800)
        }else{
            $('.n_baner').find('ul')
                .stop()
                .animate({marginLeft:-num*w_width},800);
        }
    });
    $('.n_baner').hover(function() {
        clearInterval(bannerroll)
    },function(){
        bannerroll=setInterval(move,4000);
    });



/*弹出企业动态*/
    $('.content .technology ul li').hover(function(){
        $(this).find('.technology_hide').stop().animate({
            height: "toggle",
            opacity: "toggle"
        },500)
    });
//首页产品展示

    $.caroll=function(cali,caspan){

        var caseli=$(cali).outerWidth(true);

        var caseroll=setInterval(seli,2000);

        function seli(){

            $('.n_product_box li:first').stop(true).animate({marginLeft:-caseli},1000,function(){

                $(this).appendTo('.n_product_box ul').css('margin-left',10);

            });

        };

        $('.product span.btnl').click(function() {

            seli();

        });

        $('.product span.btnr').click(function() {

            $('.n_product_box li:last').prependTo('.n_product_box ul').css('margin-left',-caseli).animate({marginLeft:10},1000);

        });

        $(caspan+','+cali).hover(function() { clearInterval(caseroll);});

        $(caspan+','+cali).mouseleave(function(){ caseroll=setInterval(seli,2000); });

    };

    $.caroll('.n_product_box li','.product span');
    /*弹出产品信息*/

    $('.close_window').click(function(){
        $('.zoom_case').fadeOut();
    });

    function bigShow() {
        var $zoom_show=$('.n_zoom .show_img');
        var $zoomli=$('.product_light ul').find('li');
        var s_li=$('.product_light ul').find('li').length-1;
        var z_i=0;
        $('.product_hiden a').on('click',function(){
            var txt=$(this).parents().siblings('p').text();
            $('.zoom_case').fadeIn();
            $zoom_show.find('img').attr('src');
            $zoom_show.find('span').text(txt);
        });
    }
    bigShow();
/*联系我们*/
    $('.img_box .img_hover').hover(function(){
        $(this).parents('.img_box').siblings('.tip_box').children('.map').eq($(this).index()).siblings('.map').fadeOut();
        $(this).parents('.img_box').siblings('.tip_box').children('.map').eq($(this).index()).fadeIn();
    });

    $('.line_box').click(function(){
        $('.zoom_case').fadeIn();
    });

    $('.btn_return').click(function(){
        $('.zoom_case').fadeOut();
    });


/*发展历程*/
    var si    = 0,
        sw    = $('.s_tab_name li').outerWidth(true),
        sleng = $('.s_tab_name li').length;


    $('.development .pre').on('click',function(){

        si<sleng-1?si++:si=0;

        $('.story_ul ul li:first').animate({marginLeft:-sw},500,function(){
            $(this).next().addClass('on').siblings().removeClass('on');
            $(this).appendTo($('.story_ul ul ')).css('margin-left',0);
        });

        $('.s_tab_content .list').eq(si).show().siblings().hide();

    })

    $('.development .next').on('click',function(){
        si>0?si--:si=sleng-1;
        $('.story_ul ul li:last').css('margin-left',-sw).prependTo($('.story_ul ul '));
        $('.story_ul ul li:first').animate({marginLeft:0},500,function(){
            $(this).addClass('on').siblings().removeClass('on');
        })
        $('.s_tab_content .list').eq(si).show().siblings().hide();
    })

    $('.s_tab_name li').on('click',function(){
        $(this).addClass('on').siblings().removeClass('on');
        data = $(this).attr('data-name');
        $('.s_tab_content .list[data-name='+data+']').show().siblings().hide ();
    })


/*    $('.maps img').hover(function() {
        var name=$(this).attr('class');
        $('div[data-name='+name+']').stop(true).fadeIn();
        $('div[data-name='+name+']').siblings().fadeOut();
    },function(){
        $('.maps .hide').fadeOut();
    });*/




    /*footer*/
    $('.left_left').hover(function(){
        $('.footer_hidden').fadeToggle();

    });




});





/*

$('.table_on').click(function(){
    $(this).toggleClass("on");
    $(this).parents('tr').next().stop().animate({
        height: "toggle",
        opacity: "toggle",
    },500)
});*/
